package edu.ucla.cs.cs144;

import java.io.StringWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;
import java.util.Date;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.text.NumberFormat;
import java.util.Collections;
import java.util.Locale;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.lucene.document.Document;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import edu.ucla.cs.cs144.DbManager;
import edu.ucla.cs.cs144.SearchRegion;
import edu.ucla.cs.cs144.SearchResult;


public class AuctionSearch implements IAuctionSearch {

	/* 
         * You will probably have to use JDBC to access MySQL data
         * Lucene IndexSearcher class to lookup Lucene index.
         * Read the corresponding tutorial to learn about how to use these.
         *
		 * You may create helper functions or classes to simplify writing these
		 * methods. Make sure that your helper functions are not public,
         * so that they are not exposed to outside of this class.
         *
         * Any new classes that you create should be part of
         * edu.ucla.cs.cs144 package and their source files should be
         * placed at src/edu/ucla/cs/cs144.
         *
         */
	
	public SearchResult[] basicSearch(String query, int numResultsToSkip, 
			int numResultsToReturn){
        
		// TODO: Your code here!
		SearchResult[] searchResults = new SearchResult[0];

        try{ 
        	// create searcher         
            Directory indexDir = FSDirectory.open(new File("/var/lib/lucene/index/"));
            IndexReader reader = DirectoryReader.open(indexDir);
            IndexSearcher searcher = new IndexSearcher(reader);
            
            // create parser
            QueryParser qParser = new QueryParser("content", new StandardAnalyzer());

            // parse the query
            Query parseredQuery = qParser.parse(query);

            TopDocs topDocs = searcher.search(parseredQuery, numResultsToSkip + numResultsToReturn);
            ScoreDoc[] hits = topDocs.scoreDocs;
            
            if(numResultsToReturn >= 0 && numResultsToSkip >= 0 && numResultsToSkip <= hits.length)
            {
                int indexStart = numResultsToSkip;
                int indexEnd = Math.min(hits.length, numResultsToSkip + numResultsToReturn);
                
                searchResults = new SearchResult[indexEnd - indexStart];
                
                for(int i = indexStart; i < indexEnd; i++)
                {
                    Document doc = searcher.doc(hits[i].doc);
                    String itemID = doc.get("ItemID");
                    String name = doc.get("Name");
                    // System.out.println(hits[i].doc + " " +hits[i].score);
                    searchResults[i - indexStart] = new SearchResult(itemID, name);
                }                
            }
            else
            {    
                searchResults  = new SearchResult[0];   
            }
            
        }catch(IOException e)
        {
            System.out.println(e);
        }
        catch(ParseException e){
            System.out.println(e);
        }
    	return searchResults;
	}

	public SearchResult[] spatialSearch(String query, SearchRegion region,
			int numResultsToSkip, int numResultsToReturn) {
		// TODO: Your code here!
        Connection conn = null;
        SearchResult[] searchResults = null;
        ArrayList<SearchResult> searchResultsTmp = new ArrayList<SearchResult>();
        ArrayList<Integer> resultIndex = new ArrayList<Integer>();

        // get basic rearch result here
        SearchResult[] searchResultsBasic = basicSearch(query, 0, 100 * (numResultsToSkip + numResultsToReturn));
        try {
            conn = DbManager.getConnection(false);
        } catch (SQLException ex) {
            System.out.println(ex);
        }

        try{
            // Creating JDBC Statement
            Statement s = conn.createStatement();
            
            // execute query, use ResultSet itemIDRS to keep the result
            s.executeUpdate("SET @poly = 'Polygon((" + region.getLx() + " " + region.getLy() + ", " + region.getRx() + " " + region.getLy() + ", "
                                + region.getRx() + " " + region.getRy() + ", " + region.getLx() + " " + region.getRy() + ", " + region.getLx() + " " + region.getLy() + "))'");
            ResultSet itemIDRS = s.executeQuery("SELECT ItemID FROM ItemLocation WHERE MBRContains(GeomFromText(@poly), Coordinate)");
            
            // compare the results of basicsearch with the results of spatial region search to get the itemID and itemName
            int id = 0;
            while (itemIDRS.next())
            {
                id = itemIDRS.getInt("ItemID");
                for (int i = 0; i < searchResultsBasic.length; i++)
                {
                    if (searchResultsBasic[i].getItemId().equals(String.valueOf(id))) 
                    {
                        // searchResultsTmp.add(new SearchResult(searchResultsBasic[i].getItemId(), searchResultsBasic[i].getName()));
                        resultIndex.add(i);
                        //System.out.println(i);
                    }   
                }
            }

            // resort the result using the ranking result from basic search
            Collections.sort(resultIndex);
            for(int i = 0; i < resultIndex.size(); i++)
            {
                searchResultsTmp.add(new SearchResult(searchResultsBasic[resultIndex.get(i)].getItemId(), searchResultsBasic[resultIndex.get(i)].getName()));
                //System.out.println("after: " + resultIndex.get(i));
            }
            
            // skip "numResultsToSkip" results
            if(numResultsToReturn >= 0 && numResultsToSkip >= 0 && numResultsToSkip <=searchResultsTmp.size())
            {
                int indexStart = numResultsToSkip;
                int indexEnd = Math.min(searchResultsTmp.size(), numResultsToSkip + numResultsToReturn);
                
                searchResults = new SearchResult[indexEnd - indexStart];
                
                for(int i = indexStart; i < indexEnd; i++)
                {
                    searchResults[i - indexStart] = searchResultsTmp.get(i);
                }
            }
            else
            {
                searchResults  = new SearchResult[0];
            }
            
            // searchResults = new SearchResult[searchResultsTmp.size()];
            // searchResultsTmp.toArray(searchResults);
            s.close();
            itemIDRS.close();
        } catch (Exception e){
        System.err.println("Error in spatialSearch");
        System.err.println(e.getMessage());
        }
		return searchResults;
	}

	public String getXMLDataForItemId(String itemId) {
		// TODO: Your code here
 
        org.w3c.dom.Document doc = null;
        DocumentBuilderFactory docFactory = null;
        DocumentBuilder docBuilder = null;
        
        SimpleDateFormat inFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0");
        SimpleDateFormat outFormat = new SimpleDateFormat("MMM-dd-yy HH:mm:ss");
    
        Statement itemTable = null, bidsTable = null, categoryTable = null, bidderTable = null, sellerTable = null;
        
        ResultSet itemRS = null, bidsRS = null, categoryRS = null, bidderRS = null, sellerRS = null;
        StringWriter writer = null;
        StreamResult result = null;
        
        TransformerFactory transFactory = null;
        Transformer transformer = null;
        Date parsed;
        
        Connection conn = null;
        
        Locale locale = new Locale("en", "US");
        NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(locale);
        
        //Connect to MySQL Database
        try{
            conn = DbManager.getConnection(false);
            
            itemTable = conn.createStatement();
            itemRS = itemTable.executeQuery("SELECT * FROM Item WHERE ItemID =" + itemId);
            
            bidsTable = conn.createStatement();
            bidsRS = bidsTable.executeQuery("SELECT * FROM Bid WHERE ItemID =" + itemId + " ORDER BY Time");
            
            categoryTable = conn.createStatement();
            categoryRS = categoryTable.executeQuery("SELECT * FROM ItemCategory WHERE ItemID =" + itemId);
            
        } catch(SQLException e) {
            e.printStackTrace();
        }
        
        //Construct <Item> XML
        try{
            docFactory = DocumentBuilderFactory.newInstance();
            docBuilder = docFactory.newDocumentBuilder();
            doc = docBuilder.newDocument();
            
            Element ItemRoot = doc.createElement("Item");
            ItemRoot.setAttribute("ItemID", itemId);
            doc.appendChild(ItemRoot);
            
            //no matching ItemId in Database
            if(!itemRS.next()){
                
                return "";
            }
            Element newElement;
            
            //Add "Name" element
            newElement = doc.createElement("Name");
            newElement.setTextContent(itemRS.getString("Name"));
            ItemRoot.appendChild(newElement);
            
            //Add "Category" element (Retrieve Info from ItemCategory Table)
            while(categoryRS.next()){
                newElement = doc.createElement("Category");
                newElement.setTextContent(categoryRS.getString("Category"));
                ItemRoot.appendChild(newElement);
            }
            
            //Add "Currently" element
            newElement = doc.createElement("Currently");
            double currently = Double.parseDouble(itemRS.getString("Currently"));
            newElement.setTextContent(currencyFormatter.format(currently));
            ItemRoot.appendChild(newElement);
            
            //Add "Buy_Price" element (may be null)
            newElement = doc.createElement("Buy_Price");
            double buy_price = Double.parseDouble(itemRS.getString("Buy_Price"));
            newElement.setTextContent(currencyFormatter.format(buy_price));
            if(Double.parseDouble(itemRS.getString("Buy_Price")) != 0.0){
                ItemRoot.appendChild(newElement);
            }
            
            //Add "First_Bid" element
            newElement = doc.createElement("First_Bid");
            double first_bid = Double.parseDouble(itemRS.getString("First_Bid"));
            newElement.setTextContent(currencyFormatter.format(first_bid));
            ItemRoot.appendChild(newElement);
            
            //Add "Number_of_Bids" element
            newElement = doc.createElement("Number_of_Bids");
            newElement.setTextContent(itemRS.getString("Number_of_Bids"));
            ItemRoot.appendChild(newElement);
            
            //Add "Bids" element
            Element Bids = doc.createElement("Bids");
            ItemRoot.appendChild(Bids);
            while(bidsRS.next()){

                Element Bid = doc.createElement("Bid");
                Bids.appendChild(Bid);
                
                bidderTable = conn.createStatement();
                bidderRS = bidderTable.executeQuery("SELECT * FROM Bidder WHERE UserID = " + "\"" + bidsRS.getString("UserID") + "\"");
                
                bidderRS.next();
                
                Element Bidder = doc.createElement("Bidder");
                Bidder.setAttribute("Rating", bidderRS.getString("Rating"));
                Bidder.setAttribute("UserID", bidderRS.getString("UserID"));
                
                //Add "Bidder" to Bid           
                //Add "Location" element (may be null) to Bidder
                newElement = doc.createElement("Location");
                newElement.setTextContent(bidderRS.getString("Location"));
                if(!bidderRS.getString("Location").equals(""))
                {                        
                    Bidder.appendChild(newElement);                        
                }
                
                //Add "Country" element (may be null) to Bidder
                newElement = doc.createElement("Country");
                newElement.setTextContent(bidderRS.getString("Country"));
                if(!bidderRS.getString("Country").equals(""))
                {                        
                    Bidder.appendChild(newElement);                        
                }
            
                Bid.appendChild(Bidder);
                
                //Add "Time" element to Bid
                newElement = doc.createElement("Time");
                parsed = inFormat.parse(bidsRS.getString("Time"));
                newElement.setTextContent(outFormat.format(parsed));
                Bid.appendChild(newElement);
                
                //Add "Amount" element to Bid
                newElement = doc.createElement("Amount");
                double amount = Double.parseDouble(bidsRS.getString("Amount"));
                newElement.setTextContent(currencyFormatter.format(amount));
                Bid.appendChild(newElement);
                
            }
            
            //Add "Location" element
            newElement = doc.createElement("Location");
            if(!itemRS.getString("Latitude").equals("")){
                newElement.setAttribute("Latitude", itemRS.getString("Latitude"));
                newElement.setAttribute("Longitude", itemRS.getString("Longitude"));
            }
            newElement.setTextContent(itemRS.getString("Location"));
            ItemRoot.appendChild(newElement);
            
            //Add "Country" element
            newElement = doc.createElement("Country");
            newElement.setTextContent(itemRS.getString("Country"));
            ItemRoot.appendChild(newElement);
          
            //Add "Started" element
            newElement = doc.createElement("Started");
            parsed = inFormat.parse(itemRS.getString("Started"));
            newElement.setTextContent(outFormat.format(parsed));
            ItemRoot.appendChild(newElement);
            
            //Add "Ends" element
            newElement = doc.createElement("Ends");
            parsed = inFormat.parse(itemRS.getString("Ends"));
            newElement.setTextContent(outFormat.format(parsed));
            ItemRoot.appendChild(newElement);
            
            //Add "Seller" element
            sellerTable = conn.createStatement();
            sellerRS = sellerTable.executeQuery("SELECT * FROM Seller WHERE UserID = " + "\"" + itemRS.getString("Seller") + "\"");
            
            sellerRS.next();
            
            Element Seller = doc.createElement("Seller");
            Seller.setAttribute("Rating", sellerRS.getString("Rating") );
            Seller.setAttribute("UserID", sellerRS.getString("UserID") );
            ItemRoot.appendChild(Seller);
            
            //Add "Description"
            newElement = doc.createElement("Description");
            newElement.setTextContent(itemRS.getString("Description"));
            ItemRoot.appendChild(newElement);
            
            //Convert doc to String
            transFactory = TransformerFactory.newInstance();
            transformer = transFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION ,"yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            
            DOMSource domSource = new DOMSource(doc);
            writer = new StringWriter();
            result = new StreamResult(writer);
            
            transformer.transform(domSource, result);

        }
        catch(ParserConfigurationException e){
            e.printStackTrace();
        }
        catch(TransformerException e){
            e.printStackTrace();
        }
        catch(DOMException e){
            e.printStackTrace();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        catch(java.text.ParseException e){
            e.printStackTrace();
        }
        
        try{
            conn.close();
        } catch (SQLException e){
            e.printStackTrace();
        }

        return writer.toString();
	}
	
	public String echo(String message) {
		return message;
	}

}
