CREATE TABLE ItemLocation(
	ItemID INT NOT NULL,
	Coordinate GEOMETRY NOT NULL,
	PRIMARY KEY(ItemID)
) ENGINE = MyISAM;

INSERT INTO ItemLocation(ItemID, Coordinate)
	SELECT ItemID, POINT(Latitude, Longitude) 
	FROM Item
	WHERE (Latitude <> "") OR (Longitude <> "");

CREATE SPATIAL INDEX sp_index ON ItemLocation(Coordinate);