ALTER TABLE ItemLocation DROP INDEX sp_index;

DROP TABLE ItemLocation;