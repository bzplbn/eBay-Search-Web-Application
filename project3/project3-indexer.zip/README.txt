This example contains a simple utility class to simplify opening database
connections in Java applications, such as the one you will write to build
your Lucene index. 

To build and run the sample code, use the "run" ant target inside
the directory with build.xml by typing "ant run".

Team Member:

Zhanwei Ye
#804618004
edisonye1992@ucla.edu

Hanjing Fang
#604588300
hjfang@ucla.edu

CS 144 Project 3
Winter 2016

-------------------------------------------------------------------------------


We used Lucene to index the fields: ItemId, Name, Category, Description, and 
Content (which was the concatenation of Name, Description, and Categories of 
an item).We created index on Name, Category, Description and Content to allow efficient, full-text keyword search across the Items table. ItemId servers as the unique identifier for the keyword search.

We also used MySQL to create a spatial index on geometric attributes such as 
latitude and longitude to support efficient spatial queries.